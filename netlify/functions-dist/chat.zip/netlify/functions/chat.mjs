
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/lib/dataLoader.ts
import { readFileSync } from "node:fs";
import path from "node:path";
import { getStore } from "@netlify/blobs";
var DATA_KEYS = [
  "thisisme",
  "academy",
  "work",
  "research",
  "courses",
  "gamefolio",
  "repofolio",
  "skills"
];
var BLOB_STORE_NAME = "resume-private";
async function loadThisIsMe() {
  try {
    const store = getStore(BLOB_STORE_NAME);
    const content = await store.get("thisisme");
    if (content && content.trim() !== "") return content;
  } catch {
  }
  const filePath = path.join(process.cwd(), "data", "thisisme.data.md");
  try {
    const content = readFileSync(filePath, "utf-8");
    if (content && content.trim() !== "") return content;
  } catch {
  }
  throw new Error("Missing or empty data file: thisisme.data.md");
}
var cachePromise = null;
async function _loadData() {
  const result = {};
  result["thisisme"] = await loadThisIsMe();
  for (const key of DATA_KEYS) {
    if (key === "thisisme") continue;
    const filePath = path.join(process.cwd(), "data", `${key}.data.md`);
    let content;
    try {
      content = readFileSync(filePath, "utf-8");
    } catch {
      throw new Error(`Missing or empty data file: ${key}.data.md`);
    }
    if (typeof content !== "string" || content.trim() === "") {
      throw new Error(`Missing or empty data file: ${key}.data.md`);
    }
    result[key] = content;
  }
  return result;
}
function loadData() {
  if (!cachePromise) {
    cachePromise = _loadData();
  }
  return cachePromise;
}

// netlify/functions/lib/promptBuilder.ts
var CHAT_EXCLUDED_KEYS = ["research"];
var BULLET_RE = /^\s*(?:[-*+]|\d+[.)])\s+/;
var LINK_RE = /\[[^\]]*\]\([^)]*\)|https?:\/\/|www\./i;
var DATE_RE = /\b(?:19|20)\d{2}\b|\b\d{4}-\d{2}(?:-\d{2})?\b|\b\d{1,2}[/.]\d{1,2}[/.]\d{2,4}\b/;
function filterMarkdownForChat(md) {
  return md.split("\n").filter((line) => {
    if (!BULLET_RE.test(line)) return true;
    return !LINK_RE.test(line) && !DATE_RE.test(line);
  }).join("\n");
}
function buildSystemPrompt(data) {
  const header = [
    `You are Daniele Quero's digital twin. Answer in first person as Daniele ("I", "my").`,
    "Respond in the language used by the user in their latest message. If ambiguous, default to English.",
    "You only answer questions about my education, professional experience, working attitude, achievements, professional behavior, courses, published games, public repositories, and technical skills. Politely decline anything else.",
    `When declining, respond with a short sentence like "Sorry, that's outside what I can share here \u2014 ask me about my education, work, or skills." (translate to the user's language).`,
    "Never invent facts. If the data does not cover something (e.g. contact details, opinions, private life), say explicitly that you don't have that information.",
    "If personality data in the <thisisme> section is minimal or empty, do not fabricate psychological traits \u2014 stay factual and professional."
  ].join("\n\n");
  const sections = DATA_KEYS.filter(
    (key) => !CHAT_EXCLUDED_KEYS.includes(key)
  ).map((key) => `<${key}>
${filterMarkdownForChat(data[key])}
</${key}>`).join("\n\n");
  const footer = "Remember: first person, user's language (English fallback), only my career/education/technical profile/working attitude/professional behavior, never invent.";
  return `${header}

${sections}

${footer}`;
}

// netlify/functions/lib/geminiClient.ts
import { GoogleGenAI } from "@google/genai";

// netlify/functions/lib/constants.ts
var MAX_OUTPUT_TOKENS = 512;

// netlify/functions/lib/geminiClient.ts
var GEMINI_MODEL = "gemini-2.0-flash";
var UpstreamError = class extends Error {
  constructor(message) {
    super(message);
    this.name = "UpstreamError";
  }
};
function toContents(history) {
  return history.map((turn) => ({
    role: turn.role === "assistant" ? "model" : "user",
    parts: [{ text: turn.content }]
  }));
}
async function* streamReply(args) {
  const { systemPrompt, history, apiKey, signal } = args;
  try {
    const ai = new GoogleGenAI({ apiKey });
    const stream = await ai.models.generateContentStream({
      model: GEMINI_MODEL,
      contents: toContents(history),
      config: {
        systemInstruction: { parts: [{ text: systemPrompt }] },
        maxOutputTokens: MAX_OUTPUT_TOKENS,
        abortSignal: signal
      }
    });
    for await (const chunk of stream) {
      if (signal?.aborted) {
        throw new UpstreamError("Aborted");
      }
      const text = chunk.text ?? "";
      if (text) {
        yield text;
      }
    }
  } catch (err) {
    if (err instanceof UpstreamError) throw err;
    const message = err instanceof Error && err.message ? err.message : "Upstream request failed";
    throw new UpstreamError(message);
  }
}

// netlify/functions/lib/groqClient.ts
import Groq from "groq-sdk";
var GROQ_MODEL = "llama-3.3-70b-versatile";
async function* streamReplyGroq(args) {
  const { systemPrompt, history, apiKey, signal } = args;
  const messages = [
    { role: "system", content: systemPrompt },
    ...history.map((turn) => ({
      role: turn.role === "assistant" ? "assistant" : "user",
      content: turn.content
    }))
  ];
  try {
    const groq = new Groq({ apiKey });
    const stream = await groq.chat.completions.create(
      {
        model: GROQ_MODEL,
        messages,
        max_tokens: MAX_OUTPUT_TOKENS,
        stream: true
      },
      { signal }
    );
    for await (const chunk of stream) {
      if (signal?.aborted) {
        throw new UpstreamError("Aborted");
      }
      const text = chunk.choices[0]?.delta?.content ?? "";
      if (text) {
        yield text;
      }
    }
  } catch (err) {
    if (err instanceof UpstreamError) throw err;
    const message = err instanceof Error && err.message ? err.message : "Groq upstream request failed";
    throw new UpstreamError(message);
  }
}

// netlify/functions/lib/providers.ts
var PROVIDER_IDS = ["gemini", "groq"];
var FIRST_TOKEN_TIMEOUT_MS = 6e3;
var OVERALL_TIMEOUT_MS = 25e3;
var STREAMERS = {
  gemini: streamReply,
  groq: streamReplyGroq
};
async function* wrapCommitted(first, iterator, overallTimer) {
  try {
    yield first;
    while (true) {
      const next = await iterator.next();
      if (next.done) break;
      yield next.value;
    }
  } finally {
    clearTimeout(overallTimer);
  }
}
async function openStreamWithFallback(preferred, args) {
  const startIdx = PROVIDER_IDS.indexOf(preferred);
  const order = [
    ...PROVIDER_IDS.slice(startIdx),
    ...PROVIDER_IDS.slice(0, startIdx)
  ];
  let lastError = null;
  for (const provider of order) {
    const apiKey = args.apiKeys[provider];
    if (!apiKey) {
      console.warn(`providers: no API key for provider "${provider}", skipping`);
      continue;
    }
    const controller = new AbortController();
    const overallTimer = setTimeout(() => controller.abort(), OVERALL_TIMEOUT_MS);
    const firstTokenTimer = setTimeout(
      () => controller.abort(),
      FIRST_TOKEN_TIMEOUT_MS
    );
    try {
      const gen = STREAMERS[provider]({
        systemPrompt: args.systemPrompt,
        history: args.history,
        apiKey,
        signal: controller.signal
      });
      const iterator = gen[Symbol.asyncIterator]();
      const firstResult = await iterator.next();
      clearTimeout(firstTokenTimer);
      if (firstResult.done) {
        clearTimeout(overallTimer);
        throw new UpstreamError(
          `Provider "${provider}" produced an empty stream`
        );
      }
      if (provider !== preferred) {
        console.info(
          `providers: fell back from "${preferred}" to "${provider}"`
        );
      }
      return {
        provider,
        stream: wrapCommitted(firstResult.value, iterator, overallTimer)
      };
    } catch (err) {
      clearTimeout(firstTokenTimer);
      clearTimeout(overallTimer);
      controller.abort();
      const msg = err instanceof Error ? err.message : String(err);
      console.warn(`providers: "${provider}" failed \u2014 ${msg}`);
      lastError = err instanceof UpstreamError ? err : new UpstreamError(msg);
    }
  }
  throw lastError ?? new UpstreamError("All providers failed");
}

// netlify/functions/lib/validation.ts
var MAX_MESSAGES = 40;
var MIN_MESSAGES = 1;
var MAX_CONTENT_CHARS = 4e3;
var MAX_TOTAL_CHARS = 6e4;
var VALID_ROLES = /* @__PURE__ */ new Set(["user", "assistant"]);
var InvalidRequestError = class extends Error {
  constructor(message) {
    super(message);
    this.name = "InvalidRequestError";
  }
};
function isPlainObject(v) {
  return typeof v === "object" && v !== null && !Array.isArray(v);
}
function parseChatRequest(body) {
  if (!isPlainObject(body)) {
    throw new InvalidRequestError("Body must be a JSON object");
  }
  const rawProvider = body["provider"];
  let provider = "gemini";
  if (rawProvider !== void 0) {
    if (!PROVIDER_IDS.includes(rawProvider)) {
      throw new InvalidRequestError(
        `'provider' must be one of: ${PROVIDER_IDS.join(", ")}`
      );
    }
    provider = rawProvider;
  }
  const rawMessages = body["messages"];
  if (!Array.isArray(rawMessages)) {
    throw new InvalidRequestError("'messages' must be an array");
  }
  if (rawMessages.length < MIN_MESSAGES || rawMessages.length > MAX_MESSAGES) {
    throw new InvalidRequestError(
      `'messages' must contain ${MIN_MESSAGES}\u2013${MAX_MESSAGES} entries`
    );
  }
  let total = 0;
  const messages = [];
  for (const item of rawMessages) {
    if (!isPlainObject(item)) {
      throw new InvalidRequestError(
        "Each message must have role 'user'|'assistant' and non-empty string content"
      );
    }
    const role = item["role"];
    const content = item["content"];
    if (typeof role !== "string" || !VALID_ROLES.has(role) || typeof content !== "string" || content.length === 0) {
      throw new InvalidRequestError(
        "Each message must have role 'user'|'assistant' and non-empty string content"
      );
    }
    if (content.length > MAX_CONTENT_CHARS) {
      throw new InvalidRequestError(
        `Each message content must be <= ${MAX_CONTENT_CHARS} chars`
      );
    }
    total += content.length;
    if (total > MAX_TOTAL_CHARS) {
      throw new InvalidRequestError(
        `Total payload exceeds ${MAX_TOTAL_CHARS} chars`
      );
    }
    messages.push({ role, content });
  }
  const last = messages[messages.length - 1];
  if (last.role !== "user") {
    throw new InvalidRequestError("Last message must be from user");
  }
  return { messages, provider };
}

// netlify/functions/chat.ts
function jsonResponse(status, body, extraHeaders) {
  const headers = {
    "content-type": "application/json"
  };
  if (extraHeaders) {
    for (const [k, v] of Object.entries(extraHeaders)) {
      headers[k] = v;
    }
  }
  return new Response(JSON.stringify(body), { status, headers });
}
function errorBody(code, message) {
  return { error: { code, message } };
}
function sseEvent(event, data) {
  return `event: ${event}
data: ${JSON.stringify(data)}

`;
}
function buildSseResponse(provider, stream) {
  const encoder = new TextEncoder();
  const body = new ReadableStream({
    async start(controller) {
      controller.enqueue(encoder.encode(sseEvent("meta", { provider })));
      try {
        for await (const chunk of stream) {
          controller.enqueue(encoder.encode(sseEvent("delta", { text: chunk })));
        }
        controller.enqueue(encoder.encode(sseEvent("done", {})));
      } catch (err) {
        console.error("chat handler: stream interrupted", err);
        controller.enqueue(
          encoder.encode(
            sseEvent("error", {
              code: "UPSTREAM_ERROR",
              message: "Stream interrupted"
            })
          )
        );
      } finally {
        controller.close();
      }
    }
  });
  return new Response(body, {
    status: 200,
    headers: {
      "content-type": "text/event-stream; charset=utf-8",
      "cache-control": "no-cache, no-transform",
      connection: "keep-alive"
    }
  });
}
var chat_default = async (req) => {
  if (req.method !== "POST") {
    return jsonResponse(
      405,
      errorBody("METHOD_NOT_ALLOWED", "Only POST is allowed"),
      { Allow: "POST" }
    );
  }
  const apiKeys = {
    gemini: process.env["CHAT_GEMINI_API_KEY"] ?? "",
    groq: process.env["CHAT_GROQ_API_KEY"] ?? ""
  };
  const hasAnyKey = Object.values(apiKeys).some((k) => k.length > 0);
  if (!hasAnyKey) {
    console.error("chat handler: no API keys configured");
    return jsonResponse(
      500,
      errorBody("MISSING_SECRET", "Chat backend not configured")
    );
  }
  let rawBody;
  try {
    rawBody = await req.json();
  } catch {
    return jsonResponse(
      400,
      errorBody("INVALID_REQUEST", "Body must be valid JSON")
    );
  }
  let messages;
  let provider;
  try {
    ({ messages, provider } = parseChatRequest(rawBody));
  } catch (err) {
    if (err instanceof InvalidRequestError) {
      return jsonResponse(400, errorBody("INVALID_REQUEST", err.message));
    }
    console.error("chat handler: unexpected validation error", err);
    return jsonResponse(
      400,
      errorBody("INVALID_REQUEST", "Invalid request payload")
    );
  }
  let systemPrompt;
  try {
    const data = await loadData();
    systemPrompt = buildSystemPrompt(data);
  } catch (err) {
    console.error("chat handler: failed to load profile data", err);
    return jsonResponse(
      500,
      errorBody("DATA_LOAD_ERROR", "Failed to load profile data")
    );
  }
  try {
    const { provider: usedProvider, stream } = await openStreamWithFallback(
      provider,
      { systemPrompt, history: messages, apiKeys }
    );
    return buildSseResponse(usedProvider, stream);
  } catch (err) {
    if (err instanceof UpstreamError) {
      console.error("chat handler: upstream error", err.message);
    } else {
      console.error("chat handler: unexpected model error", err);
    }
    return jsonResponse(
      500,
      errorBody("UPSTREAM_ERROR", "Model request failed")
    );
  }
};
export {
  chat_default as default
};
